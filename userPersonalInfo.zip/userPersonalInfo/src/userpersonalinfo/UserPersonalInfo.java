
package userpersonalinfo;

public class UserPersonalInfo {

    public static void main(String[] args) {
        // TODO code application logic here
        new personalInfo();
    }
    
}
