
package userpersonalinfo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class personalInfo extends JFrame implements ActionListener{
   //variables
    
 //panel
 private JPanel pnlMain;
 private JPanel pnlName;
 private JPanel pnlSurname;
 
 //lbl
 private JLabel lblname;
 private JLabel lblSurname;
 
  //tf
 private JTextField tfName;
 private JTextField tfSurname;
 
    public personalInfo() {
      //initial panel 
      pnlMain=new JPanel();
      pnlName=new JPanel();
      pnlSurname=new JPanel();
      
    //lbl
      lblname=new JLabel("NAME:");
      lblSurname=new JLabel("SURNAME:");
      
      //tf
      tfName=new JTextField();
      tfSurname=new JTextField();
      
      //btn
        JButton btn=new JButton("SAVE");
      
        btn.addActionListener(this);
        
      pnlMain.add(pnlName);
      pnlMain.add(pnlSurname);
      pnlMain.add(btn);
      
      //OTHER PANEL
      pnlName.add(lblname);
      pnlName.add(tfName);
      pnlSurname.add(lblSurname);
      pnlSurname.add(tfSurname);
       
      //style
      tfName.setPreferredSize(new Dimension(250,40));
      tfSurname.setPreferredSize(new Dimension(250,40));
    
      
      
      
      pnlMain.setBackground(Color.white);
      this.pack();
      this.setVisible(true);
      this.setTitle("User Personal Details");
      this.setSize(400,500);
      this.setDefaultCloseOperation(EXIT_ON_CLOSE);
      this.setContentPane(pnlMain);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
      

    }
    
}
